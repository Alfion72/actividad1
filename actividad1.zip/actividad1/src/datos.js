export const productos=[
  {
    nombre: "ervigio",
    precio: 110,
    finDeSemana: true
  },{
    nombre: "ATANAGILDO",
    precio: 125,
    finDeSemana: false
  },{
    nombre: "LEOVIGILDO",      
    precio: 73,
    finDeSemana: true
  },{
    nombre: "ATAULFO",
    precio: 69,
    finDeSemana: true
  },{
    nombre: "SISEBUTO",
    precio: 105,
    finDeSemana: false
  },{
    nombre: "TEODORICO",
    precio: 112,
    finDeSemana: true
  },{
    nombre: "RECESVINTO",
    precio: 71,
    finDeSemana: false
  }
]